"""Сборка утреннего сообщения-советника для Telegram из JSON редактора."""
import html

TELEGRAM_LIMIT = 4096

THEME_LABEL = {
    "leadership": "Лидерство",
    "marketing": "Маркетинг",
    "digital_transformation": "Цифровая трансформация",
    "robotization": "Роботизация",
}


def _esc(s: str) -> str:
    return html.escape(s or "", quote=False)


def render(data: dict) -> list[str]:
    """Список сообщений с учётом лимита Telegram (4096)."""
    note = _esc(data.get("editor_note", "")).strip()
    items = data.get("items", [])

    header = "<b>☀️ Утренний разбор: свежие темы для канала</b>"
    if note:
        header += f"\n\n{note}"

    blocks = [header]
    for it in items:
        rank = it.get("rank", "")
        flag = " 🌍 <i>эксклюзив</i>" if it.get("exclusive") else ""
        theme = THEME_LABEL.get(it.get("theme", ""), "")
        headline = _esc(it.get("headline", ""))
        summary = _esc(it.get("summary", ""))
        angle = _esc(it.get("angle", ""))
        why = _esc(it.get("why_audience", ""))
        url = it.get("url", "")
        source = _esc(it.get("source_name", ""))

        block = (
            f"<b>{rank}. {headline}</b>{flag}\n"
            f"{summary}\n\n"
            f"💡 <b>Как обыграть:</b> {angle}\n"
            f"🎯 <b>Почему зайдёт:</b> {why}\n"
            f"🔗 <a href=\"{html.escape(url, quote=True)}\">{source}</a>"
        )
        if theme:
            block += f"  ·  <i>{theme}</i>"
        blocks.append(block)

    blocks.append("Скажи, какую тему развернуть — соберём из неё пост.")

    messages, current = [], ""
    for b in blocks:
        candidate = b if not current else current + "\n\n" + b
        if len(candidate) > TELEGRAM_LIMIT:
            if current:
                messages.append(current)
            current = b
        else:
            current = candidate
    if current:
        messages.append(current)
    return messages
