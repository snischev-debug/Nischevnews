"""Конфигурация агента. Секреты — через переменные окружения (.env)."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent

# --- Telegram ---
BOT_TOKEN = os.environ["BOT_TOKEN"]                 # от @BotFather
ADMIN_CHAT_ID = int(os.environ["ADMIN_CHAT_ID"])    # твой личный chat_id — сюда приходят советы

# --- Anthropic ---
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]
MODEL = os.getenv("MODEL", "claude-opus-4-8")       # Opus 4.8 по умолчанию

# --- Расписание утренней подборки ---
DIGEST_HOUR = int(os.getenv("DIGEST_HOUR", "9"))    # час
DIGEST_MINUTE = int(os.getenv("DIGEST_MINUTE", "0"))
TIMEZONE = os.getenv("TIMEZONE", "Europe/Moscow")

# --- Параметры отбора ---
LOOKBACK_HOURS = int(os.getenv("LOOKBACK_HOURS", "36"))       # окно свежести
MAX_ITEMS_TO_LLM = int(os.getenv("MAX_ITEMS_TO_LLM", "60"))   # сколько новостей отдаём модели
TOP_N = int(os.getenv("TOP_N", "5"))

SOURCES_FILE = BASE_DIR / "sources.yaml"
AUDIENCE_FILE = BASE_DIR / "audience.md"
