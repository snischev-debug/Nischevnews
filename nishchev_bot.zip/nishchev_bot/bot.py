"""Telegram-бот «утренний советник» для канала @nishchev.

Бот НИЧЕГО не публикует в канал. Каждое утро он присылает ЛИЧНО ТЕБЕ
подборку свежих тем с советом, как обыграть их в посте.

Запуск:  python bot.py
Команды (только для ADMIN_CHAT_ID):
  /start  — проверка, что бот жив
  /digest — собрать подборку прямо сейчас
Расписание: ежедневно в DIGEST_HOUR:DIGEST_MINUTE по TIMEZONE.
"""
import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.types import Message
from apscheduler.schedulers.asyncio import AsyncIOScheduler

import config
import fetcher
import curator
import formatter

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
log = logging.getLogger("bot")

bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()


def _is_admin(chat_id: int) -> bool:
    return chat_id == config.ADMIN_CHAT_ID


async def build_briefing() -> list[str]:
    items = await fetcher.fetch_all()
    data = await curator.curate(items)
    return formatter.render(data)


async def send_to_me(messages: list[str]):
    if not messages:
        await bot.send_message(config.ADMIN_CHAT_ID, "Сегодня по темам канала ничего стоящего не нашлось.")
        return
    for m in messages:
        await bot.send_message(config.ADMIN_CHAT_ID, m, disable_web_page_preview=True)
        await asyncio.sleep(0.4)


# ── Команды ───────────────────────────────────────────────────────
@dp.message(Command("start"))
async def cmd_start(m: Message):
    if not _is_admin(m.chat.id):
        # чтобы ты легко узнал свой chat_id при первичной настройке:
        await m.answer(f"Твой chat_id: <code>{m.chat.id}</code>")
        return
    await m.answer(
        "Я на связи. Каждое утро в "
        f"{config.DIGEST_HOUR:02d}:{config.DIGEST_MINUTE:02d} ({config.TIMEZONE}) "
        "пришлю подборку свежих тем с советами по постам.\n"
        "Команда /digest — собрать прямо сейчас."
    )


@dp.message(Command("digest"))
async def cmd_digest(m: Message):
    if not _is_admin(m.chat.id):
        return
    await m.answer("Собираю свежак, пара минут…")
    try:
        await send_to_me(await build_briefing())
    except Exception as e:  # noqa: BLE001
        log.exception("Ошибка сборки подборки")
        await m.answer(f"Упал на сборке: {e}")


# ── Планировщик ───────────────────────────────────────────────────
async def scheduled_job():
    log.info("Запуск утренней подборки")
    try:
        await send_to_me(await build_briefing())
    except Exception:  # noqa: BLE001
        log.exception("Утренняя подборка упала")


async def main():
    scheduler = AsyncIOScheduler(timezone=config.TIMEZONE)
    scheduler.add_job(scheduled_job, "cron", hour=config.DIGEST_HOUR, minute=config.DIGEST_MINUTE)
    scheduler.start()
    log.info("Бот запущен. Утренняя подборка %02d:%02d %s",
             config.DIGEST_HOUR, config.DIGEST_MINUTE, config.TIMEZONE)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
